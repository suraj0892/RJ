package com.quantexures.app.service;

import org.springframework.stereotype.Service;

import com.quantexures.app.model.LoginResponse;

@Service
public class LoginService {

	public LoginResponse doUserLogin(String userName, String password,
			 String validity,String permission) {
		
		
		return new LoginResponse(Boolean.FALSE);
	}
}
