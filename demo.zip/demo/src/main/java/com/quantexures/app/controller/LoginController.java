package com.quantexures.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.quantexures.app.model.LoginResponse;
import com.quantexures.app.service.LoginService;

@RestController
@RequestMapping("api/v1")
public class LoginController {

	@Autowired
	LoginService loginService;
	
	@GetMapping("/login")
	public LoginResponse doUserLogin(
			@RequestParam(name="userName") String userName, 
			@RequestParam(name="password") String password,
			@RequestParam(name="validity") String validity,
			@RequestParam(name="permission") String permission) {
		
		
		return loginService.doUserLogin(userName, password, validity, permission);
		
	}
}
